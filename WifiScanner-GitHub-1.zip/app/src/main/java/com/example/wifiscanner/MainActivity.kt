package com.example.wifiscanner

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var wifiManager: WifiManager
    private lateinit var statusText: TextView
    private lateinit var resultsText: TextView

    private val permissionRequestCode = 1001

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val success = intent?.getBooleanExtra(
                WifiManager.EXTRA_RESULTS_UPDATED, false
            ) ?: false

            if (success) {
                showResults()
            } else {
                statusText.text = "Scan gagal atau hasil lama digunakan."
                showResults()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        statusText = findViewById(R.id.statusText)
        resultsText = findViewById(R.id.resultsText)

        findViewById<Button>(R.id.scanButton).setOnClickListener {
            startWifiScan()
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            scanReceiver,
            IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(scanReceiver)
    }

    private fun startWifiScan() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                permissionRequestCode
            )
            return
        }

        if (!isLocationEnabled()) {
            statusText.text = "Aktifkan Location/GPS Android terlebih dahulu."
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }

        statusText.text = "Sedang memindai..."
        resultsText.text = ""

        @Suppress("DEPRECATION")
        val started = wifiManager.startScan()

        if (!started) {
            statusText.text = "Scan tidak dimulai. Coba lagi beberapa saat."
        }
    }

    private fun showResults() {
        @Suppress("DEPRECATION")
        val results = wifiManager.scanResults
            .sortedByDescending { it.level }

        statusText.text = "${results.size} jaringan ditemukan."

        if (results.isEmpty()) {
            resultsText.text = "Tidak ada jaringan Wi-Fi yang ditemukan."
            return
        }

        val output = StringBuilder()

        results.forEachIndexed { index, result ->
            output.append("${index + 1}. ")
                .append(if (result.SSID.isNullOrBlank()) "<Hidden SSID>" else result.SSID)
                .append("\n")
                .append("   BSSID   : ").append(result.BSSID).append("\n")
                .append("   Signal  : ").append(result.level).append(" dBm\n")
                .append("   Frequency: ").append(result.frequency).append(" MHz\n")
                .append("   Security: ").append(securityType(result)).append("\n\n")
        }

        resultsText.text = output.toString()
    }

    private fun securityType(result: ScanResult): String {
        val caps = result.capabilities.uppercase(Locale.US)

        return when {
            "WPA3" in caps -> "WPA3"
            "WPA2" in caps -> "WPA2"
            "WPA" in caps -> "WPA"
            "WEP" in caps -> "WEP"
            else -> "Open / Unknown"
        }
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager =
            getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager

        return locationManager.isProviderEnabled(
            android.location.LocationManager.GPS_PROVIDER
        ) || locationManager.isProviderEnabled(
            android.location.LocationManager.NETWORK_PROVIDER
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == permissionRequestCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startWifiScan()
        } else {
            statusText.text = "Izin lokasi diperlukan untuk melakukan Wi-Fi scan."
        }
    }
}
